module.exports = {
    publicPath: '/CovidUpdates/'
  }
  